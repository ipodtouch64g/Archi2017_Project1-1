#ifndef mem_instruction_h
#define mem_instruction_h

#include"simulator.h"
#include"commands.h"


void MachineCodeToCommands();




#endif
